const fs = require('fs')
const fetch = require('node-fetch')

const items = require('./items.json')
let claimed = require('./claimed.json')
//let headers = require('./headers.json')
let headers = JSON.parse(fs.readFileSync('./headers.json')
	.toString()
	.split("\n").join("")
	.split(" ").join("")
)
// console.log(headers)
async function claim(unclaimedItems,n) {
	const product = unclaimedItems[n]
	// console.log(product.productId)
	// return
	let result = await fetch("https://economy.roblox.com/v1/purchases/products/"+product.productId, {
	  "headers": headers,
	  "referrer": "https://www.roblox.com/",
	  "referrerPolicy": "strict-origin-when-cross-origin",
	  "body": "{\"expectedCurrency\":1,\"expectedPrice\":0,\"expectedSellerId\":2699938435}",
	  "method": "POST",
	  "mode": "cors",
	  "credentials": "include"
	}).then(res=>res.json());
	if(result.reason) {
		console.log(result.reason,product.name)
		claimed.push(product.productId)
		fs.writeFileSync("./claimed.json",JSON.stringify(claimed))
		setTimeout(()=>{
			claim(unclaimedItems,n+1)
		},3000)
	}
	// console.log(result)
	if(result.errors) {
		console.log("Rate limited on",product.name,': retrying in 30 seconds')
		setTimeout(()=>{
			claim(unclaimedItems,n)
		},30000)
	}
	if(result.message=="Token Validation Failed") {
		console.log("Refresh your headers")
		// console.log(result)
		// exit()
	}
	
}

async function claimUnclaimed(){
	const claimableItems = items
		.filter(i=>i.itemType.indexOf("Bundle")!=-1)
		// console.log(claimableItems.length)
	const unclaimedItems = claimableItems
		.filter(i=>claimed.indexOf(i.productId)==-1)
	console.log("Claiming",unclaimedItems.length+"/"+claimableItems.length,'remaining items')
	claim(unclaimedItems,0)
}

claimUnclaimed()
