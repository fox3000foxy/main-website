const fetch = require('node-fetch')
let headers = require('./headers.json')

allItems = []
async function main(next_page=null,max_pages=0) {
	const page = parseInt(next_page ? next_page[0] : 1)
	console.log(`Fetching page ${page}`)
	const items = await fetch("https://catalog.roblox.com/v1/search/items?category=All&limit=120&maxPrice=0&minPrice=0&salesTypeFilter=1"+(next_page?"&cursor="+next_page:""), {
	  "headers": {"accept": "application/json, text/plain",	"accept-language": "fr-FR,fr;q=0.9,ja-JP;q=0.8,ja;q=0.7,en-US;q=0.6,en;q=0.5",	"sec-ch-ua": "\"Google Chrome\";v=\"117\", \"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"117\"","sec-ch-ua-mobile": "?0","sec-ch-ua-platform": "\"Windows\"","sec-fetch-dest": "empty","sec-fetch-mode": "cors","sec-fetch-site": "same-site","x-bound-auth-token": "token"},
	  "referrer": "https://www.roblox.com/",
	  "referrerPolicy": "strict-origin-when-cross-origin",
	  "body": null,
	  "method": "GET",
	  "mode": "cors",
	  "credentials": "include"
	}).then(res=>res.json());

	console.log(items.nextPageCursor)

	const newItems = items.data.map(i=> {
		return ({"itemType":"Bundle",...i})
	})

	const details = await fetch("https://catalog.roblox.com/v1/catalog/items/details", {
	  "headers": headers,
	  "body": JSON.stringify({items:newItems}),
	  "method": "POST"
	}).then(res=>res.json());

	// console.log(details)

	allItems = [...new Set([...allItems,...details.data])]
	fs.writeFileSync("./items/items-"+page+".json",JSON.stringify(allItems,null,2))
	console.log("Saving all from 1 to " + page)
	if(items.nextPageCursor && parseInt(items.nextPageCursor[0])<=max_pages) {
		setTimeout(()=>{
			main(items.nextPageCursor,max_pages)
		},1000)
		return
	}
	else {
		fs.writeFileSync("./items.json",JSON.stringify(allItems,null,2))
	}
}
const fs = require('fs')

main(null,20)

